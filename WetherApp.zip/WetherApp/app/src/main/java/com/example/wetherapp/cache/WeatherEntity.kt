package com.example.wetherapp.cache

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "product_table")
data class WeatherEntity(
    var description: String,
    var temp: Int,
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0
)
