package com.example.wetherapp.forecastFragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wetherapp.R
import com.example.wetherapp.cache.WeatherEntity
import com.example.wetherapp.databinding.FragmentForecastBinding
import com.example.wetherapp.mapper.WeatherEntityToModelMapper

class ForecastFragment: Fragment(R.layout.fragment_forecast) {

    companion object{
        const val TAG = "ForecastFragment"
    }

    private val viewModel: ForecastFragmentViewModel = ForecastFragmentViewModel()
    private lateinit var binding: FragmentForecastBinding
    private var adapter = ForecastAdapter()
    private val weatherEntityMapper = WeatherEntityToModelMapper()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentForecastBinding.bind(super.onCreateView(inflater, container, savedInstanceState)!!)

        binding.rvWeather.addItemDecoration(
            DividerItemDecoration(
                context,
                LinearLayoutManager.HORIZONTAL
            )
        )

        setupAdapter()
        viewModel.dataConvert()
        viewModel.weatherLiveData.observe(viewLifecycleOwner) { listOfWeather ->
            initRecyclerView(listOfWeather)
        }
        setupListener()
        return binding.root
    }

    private fun initRecyclerView(listOfWeather: List<WeatherEntity>?) {
        adapter = ForecastAdapter().apply {
            items = listOfWeather?.let { weatherEntityMapper.list(it) }!!
        }
    }

    private fun setupListener() {

    }

    private fun setupAdapter() {
        binding.rvWeather.adapter = adapter
    }
}