package com.example.wetherapp.forecastFragment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wetherapp.WeatherApp
import com.example.wetherapp.cache.WeatherEntity
import com.example.wetherapp.model.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ForecastFragmentViewModel: ViewModel() {

    private val weather = MutableLiveData<List<WeatherEntity>>()
    val weatherLiveData: LiveData<List<WeatherEntity>> = weather

    fun dataConvert(){
        viewModelScope.launch  (Dispatchers.IO) {
            weather.postValue(WeatherApp.db.fetchAll())
        }
    }
}