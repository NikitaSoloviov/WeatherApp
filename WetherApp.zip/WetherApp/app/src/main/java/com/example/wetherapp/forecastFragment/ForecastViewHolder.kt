package com.example.wetherapp.forecastFragment

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.wetherapp.databinding.WeatherCellBinding
import com.example.wetherapp.model.Weather

class ForecastViewHolder(view: View): RecyclerView.ViewHolder(view) {

    private val binding = WeatherCellBinding.bind(view)

    fun bind(weather: Weather,){

        binding.tvWeather.text = weather.description
        binding.tvTempNum.text = weather.temp.toString()
    }
}
