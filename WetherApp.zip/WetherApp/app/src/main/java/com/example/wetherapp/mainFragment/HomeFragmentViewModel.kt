package com.example.wetherapp.mainFragment

import android.util.Log
import androidx.appcompat.widget.AppCompatEditText
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wetherapp.WeatherApp
import com.example.wetherapp.cache.WeatherEntity
import com.example.wetherapp.model.Weather
import com.example.wetherapp.model.WeatherResponse
import com.example.wetherapp.network.Constants
import com.example.wetherapp.network.WeatherService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import java.net.URL

class HomeFragmentViewModel : ViewModel() {

    private val dataBase = WeatherApp.db


    fun fetchData(etCityName: String) {

        val retrofit: Retrofit = Retrofit.Builder().baseUrl(Constants.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()).build()
        val service: WeatherService = retrofit.create(WeatherService::class.java)

        val listCall: Call<WeatherResponse> = service.getWeather(
            etCityName, Constants.API_KEY
        )

        listCall.enqueue(object : Callback<WeatherResponse> {

            override fun onResponse(
                call: Call<WeatherResponse>,
                response: Response<WeatherResponse>
            ) {
                if (response!!.isSuccessful) {

                    val responseList: WeatherResponse? = response.body()
                    Log.i("test", "$responseList, ${response.code()}")

                } else {
                    val responseCode = response.code()
                    when (responseCode) {
                        400 -> {
                            Log.e("Error 400", "Bad Connction")
                        }
                        404 -> {
                            Log.e("Error 404", "Not Found")
                        }
                        else -> {
                            Log.e("Error", "Generic Error")
                        }
                    }
                }
            }

            override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {

                Log.i("test", t.stackTraceToString())
            }

        })
    }
}


//    fun fetchData(etCityName: String) {
////        val baseUrl = "https://api.openweathermap.org/data/2.5/forecast?q=${etCityName}&appid=65d00499677e59496ca2f318eb68c049"
//        viewModelScope.launch ( Dispatchers.IO ){
//
////            val resultJson = URL(baseUrl).readText()
////            Log.d("Weather Report", resultJson)
////            val jsonObj = JSONObject(resultJson)
////            val mainObj = jsonObj.getJSONObject("main")
////            val temp = mainObj.getString("temp")
////            val weather = jsonObj.getJSONObject("weather")
////            val main = weather.getString("main") ??
//
////            dataBase.saveOne(WeatherEntity(main, 10))
//        }
//    }
//}
