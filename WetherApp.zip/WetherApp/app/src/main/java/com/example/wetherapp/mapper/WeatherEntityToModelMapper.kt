package com.example.wetherapp.mapper

import com.example.wetherapp.cache.WeatherEntity
import com.example.wetherapp.model.Weather

class WeatherEntityToModelMapper: Mapper<WeatherEntity, Weather> {

    override fun map(source: WeatherEntity): Weather {
        return Weather(
            source.description,
            source.temp
        )
    }
}