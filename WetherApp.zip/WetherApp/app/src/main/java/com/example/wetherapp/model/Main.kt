package com.example.wetherapp.model

data class Main(
    val temp: Int
) : java.io.Serializable

