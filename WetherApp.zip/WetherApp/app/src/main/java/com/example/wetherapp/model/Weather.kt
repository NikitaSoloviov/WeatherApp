package com.example.wetherapp.model

data class Weather(
    var description: String,
    var temp: Int
)
