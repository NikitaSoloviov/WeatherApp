package com.example.wetherapp.model

data class WeatherObj(
    var description: String
)
