package com.example.wetherapp.model

data class WeatherResponse(
    val main: Main,
    val weather: Weather
):java.io.Serializable
