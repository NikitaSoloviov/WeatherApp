package com.example.wetherapp.model

data class Wind (
    val speed: Int,
    val deg: Int
    ):java.io.Serializable
