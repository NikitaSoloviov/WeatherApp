package com.example.wetherapp.network

import android.content.Context
import android.net.ConnectivityManager

object Constants {

    const val BASE_URL: String = "https://api.openweathermap.org/data/"
    const val API_KEY: String = "65d00499677e59496ca2f318eb68c049"
}